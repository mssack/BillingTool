using System;
using System.ComponentModel;






namespace BillingTool.enumerations
{
	/// <summary>Describes the possible types for a BelegData.</summary>
	[Serializable]
	public enum BelegDataTypes
	{


		/// <summary>Money exchanged cash.</summary>
		Bar = 11,
		/// <summary>Money exchanged with cash dispenser.</summary>
		Bankomat = 12,
		/// <summary>Money exchanged with cash dispenser.</summary>
		Kreditkarte = 13,




	}
}
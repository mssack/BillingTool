using System;
using System.ComponentModel;






namespace BillingTool.enumerations
{
	/// <summary>The possible startup modes of the application. The mode defines the functionality of an application instance.</summary>
	[Serializable]
	public enum StartupModes
	{
		/// <summary>No startup mode is defined. The application will exit.</summary>
		Undefined,

		/// <summary>for testing purpose.</summary>
		Database,


		/// <summary>Allows re-printing, re-mailing or even canceling a previous created BelegData. Can also be used to manually create a new BelegData.</summary>
		BelegDataViewer,
		/// <summary>Allows the creation of a new BelegData.</summary>
		BelegDataApprove,
		/// <summary>Allows modifying the options of the program.</summary>
		Options,

		/// <summary>Allows modifying the options of the program.</summary>
		SilentMonatsBonPrint,
	}
}